  <!--comment>
            Crear tarjeta

            Hace uso del formulario para crear una grupoempresa
    </comment-->
<!DOCTYPE html>
<head>
<title> Registrar Grupo Empresa | Gestion TIS </title>
</head>
<body>
<div class="container">

<form action="{{url('/grupoempresa')}}" method="post" enctype="multipart/form-data">
@csrf
@include('grupoempresa.form',['modo'=>'Registrar'])
</div>
</body>

<html>


